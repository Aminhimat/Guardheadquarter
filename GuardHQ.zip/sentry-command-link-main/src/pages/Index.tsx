import SecurityPlatformLanding from "@/components/SecurityPlatformLanding";

const Index = () => {
  return <SecurityPlatformLanding />;
};

export default Index;
